package jrtr;

/**
 * Manages shaders for the software renderer. Not implemented here.
 */
public class SWShader implements Shader {

	public void disable() {
	}

	public void load(String vertexFileName, String fragmentFileName)
			throws Exception {
	}

	public void use() {
	}

}